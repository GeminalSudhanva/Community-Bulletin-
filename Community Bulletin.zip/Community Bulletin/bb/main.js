// JavaScript for the upvote and downvote actions (as an example)
const upvoteButtons = document.querySelectorAll('.upvote');
const downvoteButtons = document.querySelectorAll('.downvote');

upvoteButtons.forEach(button => {
    button.addEventListener('click', function() {
        const votes = this.nextElementSibling;
        votes.innerText = parseInt(votes.innerText) + 1;
    });
});

downvoteButtons.forEach(button => {
    button.addEventListener('click', function() {
        const votes = this.previousElementSibling;
        votes.innerText = parseInt(votes.innerText) - 1; // Decrement the vote count
    });
});

document.querySelector('.dropdown').addEventListener('click', function(e) {
    const dropdownContent = this.querySelector('.dropdown-content');
    dropdownContent.style.display = dropdownContent.style.display === 'block' ? 'none' : 'block';
});

// -------------
function loadPosts() {
    const postSection = document.getElementById('post-section');
    const posts = JSON.parse(localStorage.getItem('posts')) || [];
    postSection.innerHTML = '';

    // Define mood-to-color mapping
    const moodColors = {
      happy: '#2aff4a', // Gold
      sad: '#87CEEB', // Sky Blue
      neutral: '#D3D3D3', // Light Gray
      excited: '#FF69B4', // Hot Pink
      angry: '#ff0024', 
    };

    posts.forEach(post => {
      const postDiv = document.createElement('div');
      postDiv.classList.add('post');
      
      // Set background color based on mood
      const moodColor = moodColors[post.mood] || '#FFFFFF'; // Default to white if mood is not found
      postDiv.style.background = `linear-gradient(to right, ${moodColor}, #FFFFFF)`;

      postDiv.innerHTML = `
        <div class="post-info">
          <div class="upvote">⬆️</div>
          <div class="votes">0</div>
          <div class="downvote">⬇️</div>
        </div>
        <div class="post-content">
          <h4>${post.type}</h4>
          <p>${post.content}</p>
          ${post.image ? `<img src="${post.image}" alt="Post Image" style="margin-top: 10px;">` : ''}
        </div>
      `;

      postSection.appendChild(postDiv);
    });
  }

  window.onload = loadPosts;
// header carousal
let sportsIndex = 0;
        const sportsItems = document.querySelectorAll('#sportsCarousel .carousel-item');
        const totalSportsItems = sportsItems.length;

        function moveToNextSportsItem() {
            sportsIndex = (sportsIndex + 1) % totalSportsItems;
            const newTransformValue = -100 * sportsIndex + '%';
            document.querySelector('#sportsCarousel .carousel-container').style.transform = `translateX(${newTransformValue})`;
        }

        setInterval(moveToNextSportsItem, 5000); 