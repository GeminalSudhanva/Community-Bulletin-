const express = require('express');
const router = express.Router();
const db = require('../../db');

// Fetch all posts
router.get('/posts', (req, res) => {
  db.query('SELECT * FROM posts ORDER BY created_at DESC', (err, results) => {
    if (err) res.status(500).json({ error: 'Database query error' });
    else res.json(results);
  });
});

// Add a new post
router.post('/posts', (req, res) => {
  const { title, content, author } = req.body;
  const query = 'INSERT INTO posts (title, content, author) VALUES (?, ?, ?)';
  db.query(query, [title, content, author], (err) => {
    if (err) res.status(500).json({ error: 'Database query error' });
    else res.status(201).json({ message: 'Post added successfully' });
  });
});

// Update votes
router.put('/posts/:id/vote', (req, res) => {
  const { id } = req.params;
  const { vote } = req.body; // +1 for upvote, -1 for downvote
  db.query('UPDATE posts SET votes = votes + ? WHERE id = ?', [vote, id], (err) => {
    if (err) res.status(500).json({ error: 'Database query error' });
    else res.json({ message: 'Vote updated successfully' });
  });
});

module.exports = router;
