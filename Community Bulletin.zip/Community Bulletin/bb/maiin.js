const postSection = document.querySelector('.post-section');

// Fetch posts from the backend
async function fetchPosts() {
  try {
    const response = await fetch('http://localhost:5000/api/posts');
    const posts = await response.json();

    postSection.innerHTML = '';
    posts.forEach(post => {
      const postElement = `
        <div class="post">
          <div class="post-info">
            <div class="upvote" onclick="votePost(${post.id}, 1)">⬆️</div>
            <div class="votes">${post.votes}</div>
            <div class="downvote" onclick="votePost(${post.id}, -1)">⬇️</div>
          </div>
          <div class="post-content">
            <h4>${post.title}</h4>
            <p>${post.content}</p>
            <span>Posted by: ${post.author}</span>
          </div>
        </div>
      `;
      postSection.innerHTML += postElement;
    });
  } catch (error) {
    console.error('Error fetching posts:', error);
  }
}

// Submit a new post
async function submitPost(title, content, author) {
  try {
    await fetch('http://localhost:5000/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, content, author }),
    });
    fetchPosts();
  } catch (error) {
    console.error('Error submitting post:', error);
  }
}

// Upvote or downvote a post
async function votePost(postId, vote) {
  try {
    await fetch(`http://localhost:5000/api/posts/${postId}/vote`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ vote }),
    });
    fetchPosts();
  } catch (error) {
    console.error('Error voting on post:', error);
  }
}

// Initial Fetch
fetchPosts();
