document
  .getElementById("register-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const age = parseInt(document.getElementById("age").value);
    const username = document.getElementById("username").value;

    
    if (email && password && age && username) {
      alert("Account Created Successfully! Redirecting to login page...");
      
      window.location.href = "login.html";
    } else {
      alert("Please fill in all fields");
    }
  });
